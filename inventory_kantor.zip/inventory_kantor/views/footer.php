</body>
<footer>
    &copy; 2025 Data Inventaris Kantor | Developed by Nidia Denova Lukitasari | 40011423650333 💻
		Akuntansi Perpajakan | Sekolah Vokasi | Universitas Diponegoro
</footer>
</html>
