<!-- includes/navbar.php -->
<div class="sidebar">
    <h2>Inventory Kantor</h2>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="data_lokasi.php">Data Lokasi</a></li>
        <li><a href="data_kategori.php">Data Kategori</a></li>
		<li><a href="data_pemeliharaan.php">Data Pemeliharaan</a></li>		
        <li><a href="data_inventaris.php">Data Inventaris</a></li>
    </ul>
</div>

<style>
.sidebar {
	font-family: gothic bold;
    width: 230px;
    background-color: white;
    padding: 20px;
    float: left;
    height: 50vh;
	border-radius: 10px; 
	box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
}

.sidebar h2 {
    color: #333;
    font-size: 24px;
    margin-bottom: 20px;
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
}

.sidebar ul li {
    margin: 10px 0;
}

.sidebar ul li a {
    text-decoration: none;
    color: #0066cc;
    display: block;
    padding: 8px;
    border-radius: 4px;
}

.sidebar ul li a:hover {
    background-color: #ddd;
}
</style>
