<?php

// Fungsi untuk menampilkan semua data kategori
function getKategori($conn) {
    $kategori = [];
    $result = $conn->query("SELECT * FROM kategori ORDER BY nama_kategori ASC");
    while ($row = $result->fetch_assoc()) {
        $kategori[] = $row;
    }
    return $kategori;
}

// Fungsi untuk menampilkan semua data lokasi
function getLokasi($conn) {
    $lokasi = [];
    $result = $conn->query("SELECT * FROM lokasi ORDER BY nama_lokasi ASC");
    while ($row = $result->fetch_assoc()) {
        $lokasi[] = $row;
    }
    return $lokasi;
}

// Fungsi untuk ambil nama kategori berdasarkan ID
function getKategoriById($conn, $id) {
    $stmt = $conn->prepare("SELECT nama_kategori FROM kategori WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($nama);
    $stmt->fetch();
    $stmt->close();
    return $nama;
}

// Fungsi untuk ambil nama lokasi berdasarkan ID
function getLokasiById($conn, $id) {
    $stmt = $conn->prepare("SELECT nama_lokasi FROM lokasi WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($nama);
    $stmt->fetch();
    $stmt->close();
    return $nama;
}
?>
