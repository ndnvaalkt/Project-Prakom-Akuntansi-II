<?php include 'views/header.php'; ?>

<!-- Container Start -->
<div style="background-color: #d0ebff; padding: 55px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">

<!-- Halaman Awal -->
<div style="text-align: center; padding: 100px 20px; background-color: #d0ebff;">
    <img src="logo.png" alt="Logo Kantor" style="height: 240px; margin-bottom: 20px;"> <!-- Ukuran diperbesar & jarak diperkecil -->
    <h1 style="font-size: 32px; font-family: 'Gothic Bold', sans-serif; margin-bottom: 40px; margin-top: 0;">
        DATA INVENTARIS KANTOR
    </h1>
    <a href="data_inventaris.php">
        <button style="padding: 12px 25px; font-size: 16px; background-color: #0066cc; color: white; border: none; border-radius: 6px; cursor: pointer;">
            Lihat Data Inventaris
        </button>
    </a>
</div>
<?php include 'views/footer.php'; ?>
