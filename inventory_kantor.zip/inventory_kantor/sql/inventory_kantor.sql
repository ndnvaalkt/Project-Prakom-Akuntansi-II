-- Hapus database lama jika ada
DROP DATABASE IF EXISTS inventory_kantor;

-- Buat database baru
CREATE DATABASE inventory_kantor;
USE inventory_kantor;

-- Tabel kategori
CREATE TABLE kategori (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_kategori VARCHAR(100) NOT NULL
);

-- Tabel lokasi
CREATE TABLE lokasi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_lokasi VARCHAR(100) NOT NULL
);

-- Tabel inventaris
CREATE TABLE inventaris (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode_label VARCHAR(50) UNIQUE,
    id_barang VARCHAR(100),
    nama_barang VARCHAR(255),
    status ENUM('Tersedia', 'Dipinjam', 'Rusak', 'Ditempatkan') DEFAULT 'Tersedia',
    lokasi_id INT,
    kategori_id INT,
    tanggal_masuk DATE,
    FOREIGN KEY (lokasi_id) REFERENCES lokasi(id),
    FOREIGN KEY (kategori_id) REFERENCES kategori(id)
);

-- Tabel pemeliharaan
CREATE TABLE pemeliharaan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode_label VARCHAR(50) NOT NULL,
    id_barang VARCHAR(50) NOT NULL,
    nama_barang VARCHAR(100) NOT NULL,
    tanggal DATE NOT NULL,
    keterangan TEXT
);

-- Masukkan data kategori
INSERT INTO kategori (nama_kategori) VALUES
('Elektronik'), 
('Furniture'), 
('ATK');

-- Masukkan data lokasi
INSERT INTO lokasi (nama_lokasi) VALUES
('Lemari ATK'),
('Ruang Logistik'),
('Gudang Elektronik');

-- Masukkan data inventaris
INSERT INTO inventaris (kode_label, id_barang, nama_barang, status, lokasi_id, kategori_id, tanggal_masuk) VALUES
('EL-001', 'SN1230', 'Proyektor Epson', 'Dipinjam', 3, 1, '2025-01-10'),
('EL-002', 'SN1231', 'Printer Epson', 'Ditempatkan', 3, 1, '2025-01-15'),
('FR-001', 'SN1232', 'Meja Kerja', 'Ditempatkan', 2, 2, '2025-01-12'),
('ATK-001', 'SN1233', 'Tinta Printer Epson 003', 'Ditempatkan', 1, 3, '2025-02-01'),
('FR-002', 'SN1234', 'Kursi Putar', 'Tersedia', 2, 2, '2025-02-14'),
('EL-003', 'SN1235', 'Scanner HP', 'Rusak', 3, 1, '2025-02-22'),
('ATK-002', 'SN1236', 'Map Folder', 'Tersedia', 1, 3, '2025-03-05'),
('EL-004', 'SN1237', 'Monitor LG 24"', 'Dipinjam', 3, 1, '2025-03-17'),
('FR-003', 'SN1238', 'Sofa Tamu', 'Ditempatkan', 2, 2, '2025-03-23'), 
('ATK-003', 'SN1239', 'Kertas HVS A4 80 gsm', 'Ditempatkan', 1, 3, '2025-04-03'),
('EL-005', 'SN1240', 'Speaker Bluetooth', 'Rusak', 3, 1, '2025-04-15'), 
('ATK-004', 'SN1241', 'Whiteboard', 'Dipinjam', 1, 3, '2025-04-21'), 
('FR-004', 'SN1242', 'Loker Pegawai', 'Rusak', 2, 2, '2025-05-04'),
('FR-005', 'SN1243', 'Podium', 'Dipinjam', 2, 2, '2025-05-11'),
('EL-006', 'SN1244', 'Laptop ASUS', 'Tersedia', 3, 1, '2025-05-19'),
('ATK-005', 'SN1245', 'Cartridge Toner LaserJet', 'Tersedia', 1, 3, '2025-05-26'),
('ATK-006', 'SN1246', 'Mesin Laminating', 'Rusak', 1, 3, '2025-06-02'),
('FR-006', 'SN1247', 'Rak Buku Kantor', 'Rusak', 2, 2, '2025-06-14'),
('EL-007', 'SN1248', 'Mesin Fotokopi', 'Ditempatkan', 3, 1, '2025-06-19'),
('FR-007', 'SN1249', 'Partisi Kantor', 'Ditempatkan', 2, 2, '2025-06-25'),
('ATK-007', 'SN1250', 'Paper Clip', 'Tersedia', 1, 3, '2025-06-28'),
('FR-008', 'SN1251', 'Kursi Lipat', 'Dipinjam', 2, 2, '2025-07-01'),
('FR-009', 'SN1252', 'Kabinet Dokumen', 'Tersedia', 2, 2, '2025-07-07');
