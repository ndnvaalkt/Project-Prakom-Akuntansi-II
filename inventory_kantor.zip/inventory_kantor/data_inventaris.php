<?php 
include 'includes/db.php'; 
include 'includes/navbar.php'; 
include 'views/header.php'; 
?>

<!-- Container Start -->
<div style="background-color: #d0ebff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">

<!-- Konten Utama -->
<div class="content" style="margin-left: 270px; padding: 20px; background: white; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">

    <!-- LOGO DAN JUDUL -->
    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 20px;">
	    <img src="logo.png" alt="Logo Kantor" style="height: 100px;">
        <h2 style="margin: 0; font-size: 26px;">DATA INVENTARIS KANTOR</h2>
    </div>

    <!-- FORM FILTER -->
    <form method="GET" action="data_inventaris.php" style="margin-bottom: 20px;">
        <label>Kategori: </label>
        <select name="kategori_id">
            <option value="">---</option>
            <?php
            $kategori = $conn->query("SELECT * FROM kategori");
            while ($k = $kategori->fetch_assoc()) {
                $sel = (isset($_GET['kategori_id']) && $_GET['kategori_id']==$k['id']) ? 'selected' : '';
                echo "<option value='{$k['id']}' $sel>{$k['nama_kategori']}</option>";
            }
            ?>
        </select>

        <label>Status: </label>
        <select name="status">
            <option value="">---</option>
            <?php
            $statuses = ['Tersedia','Dipinjam','Ditempatkan','Rusak'];
            foreach ($statuses as $st) {
                $sel = (isset($_GET['status']) && $_GET['status']==$st) ? 'selected' : '';
                echo "<option value='$st' $sel>$st</option>";
            }
            ?>
        </select>

        <button type="submit">Tampil</button>

		<label>Cari: </label>
		<input type="text" name="keyword" placeholder="Nama atau Kode Label" value="<?= isset($_GET['keyword']) ? $_GET['keyword'] : '' ?>">

		<button type="submit">Tampil</button>
	</form>

    </form>

    <!-- TABEL -->
    <table border="1" cellpadding="8" cellspacing="0" style="width: 100%; border-collapse: collapse;">
        <tr style="background-color: #f2f2f2;">
            <th>No</th>
			<th>Kode Label</th>
			<th>ID Barang</th>
            <th>Nama Barang</th>
			<th>Status</th>
			<th>Lokasi</th>
			<th>Kontrol</th>
        </tr>
        <?php
        $sql = "SELECT i.*, l.nama_lokasi, k.nama_kategori
                FROM inventaris i
                LEFT JOIN lokasi l ON i.lokasi_id = l.id
                LEFT JOIN kategori k ON i.kategori_id = k.id";

        $w = [];
        if (!empty($_GET['kategori_id'])) {
            $idk = intval($_GET['kategori_id']);
            $w[] = "i.kategori_id = $idk";
        }
        if (!empty($_GET['status'])) {
            $st = $conn->real_escape_string($_GET['status']);
            $w[] = "i.status = '$st'";
        }
		if (!empty($_GET['keyword'])) {
			$keyword = $conn->real_escape_string($_GET['keyword']);
			$w[] = "(i.nama_barang LIKE '%$keyword%' OR i.kode_label LIKE '%$keyword%')";
		}
		 if (count($w)>0) {
            $sql .= " WHERE " . implode(" AND ", $w);
		 }

        $res = $conn->query($sql);
        $no = 1;
        while ($row = $res->fetch_assoc()):
        $statusClass = "status-" . htmlspecialchars($row['status']);
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($row['kode_label']) ?></td>
            <td><?= htmlspecialchars($row['id_barang']) ?></td>
            <td><?= htmlspecialchars($row['nama_barang']) ?></td>
            <td><span class="status-badge <?= $statusClass ?>"><?= htmlspecialchars($row['status']) ?></span></td>
            <td><?= htmlspecialchars($row['nama_lokasi']) ?></td>
            <td>
                <a class="kontrol-btn kontrol-pemeliharaan" href="kontrol/pemeliharaan.php?id=<?= $row['id'] ?>">🛠 Pemeliharaan</a>
                <a class="kontrol-btn kontrol-resume" href="kontrol/resume.php?id=<?= $row['id'] ?>">📋 Resume</a>
                <a class="kontrol-btn kontrol-edit" href="kontrol/edit.php?id=<?= $row['id'] ?>">✏️ Edit</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

</div>

<?php include 'views/footer.php'; ?>
