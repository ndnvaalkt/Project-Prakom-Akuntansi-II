<?php 
include 'includes/db.php';      // $conn sudah dibuat di sini
include 'includes/navbar.php'; 
include 'views/header.php'; 

$query  = "SELECT * FROM lokasi";
$result = $conn->query($query);

if (!$result) {
    die("Query error: " . $conn->error);
}
?>


<!-- Container Start -->
<div style="background-color: #d0ebff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">

<!-- Konten Utama -->
<div class="content" style="margin-left: 270px; margin-bottom: 290px; padding: 60px; background: white; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">

    <!-- LOGO DAN JUDUL -->
    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 20px;">
	    <img src="logo.png" alt="Logo Kantor" style="height: 100px;">
        <h2 style="margin: 0; font-size: 26px;">DATA LOKASI</h2>
    </div>

<!-- TABEL -->
<table border="1" cellpadding="8" cellspacing="0" style="width: 100%; border-collapse: collapse;">
    <tr style="background-color: #f2f2f2;">
        <th>No</th>
        <th>Nama Lokasi</th>
    </tr>
    <?php
    $no = 1;
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>$no</td>
                <td>{$row['nama_lokasi']}</td>
              </tr>";
        $no++;
    }
    ?>
</table>


</div>

<?php include 'views/footer.php'; ?>
