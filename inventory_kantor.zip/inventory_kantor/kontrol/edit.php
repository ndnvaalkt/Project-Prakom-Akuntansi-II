<?php
include '../includes/db.php';

$id = $_GET['id'];
$query = "SELECT * FROM inventaris WHERE id = $id";
$result = $conn->query($query);
$data = $result->fetch_assoc();

// ambil data lokasi dan kategori untuk dropdown
$lokasi = $conn->query("SELECT * FROM lokasi");
$kategori = $conn->query("SELECT * FROM kategori");
?>

<h2>Edit Data Inventaris</h2>
<form method="POST" action="">
    <input type="hidden" name="id" value="<?= $data['id'] ?>">

    <label>Kode Label:</label><br>
    <input type="text" name="kode_label" value="<?= $data['kode_label'] ?>"><br>

    <label>ID Barang:</label><br>
    <input type="text" name="id_barang" value="<?= $data['id_barang'] ?>"><br>

    <label>Nama Barang:</label><br>
    <input type="text" name="nama_barang" value="<?= $data['nama_barang'] ?>"><br>

    <label>Status:</label><br>
    <select name="status">
        <option <?= $data['status'] == 'Tersedia' ? 'selected' : '' ?>>Tersedia</option>
        <option <?= $data['status'] == 'Ditempatkan' ? 'selected' : '' ?>>Ditempatkan</option>
        <option <?= $data['status'] == 'Dipinjam' ? 'selected' : '' ?>>Dipinjam</option>
        <option <?= $data['status'] == 'Rusak' ? 'selected' : '' ?>>Rusak</option>
    </select><br>

    <label>Lokasi:</label><br>
    <select name="lokasi_id">
        <?php while ($row = $lokasi->fetch_assoc()) {
            $selected = $row['id'] == $data['lokasi_id'] ? 'selected' : '';
            echo "<option value='{$row['id']}' $selected>{$row['nama_lokasi']}</option>";
        } ?>
    </select><br>

    <label>Kategori:</label><br>
    <select name="kategori_id">
        <?php while ($row = $kategori->fetch_assoc()) {
            $selected = $row['id'] == $data['kategori_id'] ? 'selected' : '';
            echo "<option value='{$row['id']}' $selected>{$row['nama_kategori']}</option>";
        } ?>
    </select><br><br>

    <button type="submit" name="simpan">Simpan</button>
</form>

<?php
if (isset($_POST['simpan'])) {
    $id = $_POST['id'];
    $kode_label = $_POST['kode_label'];
    $id_barang = $_POST['id_barang'];
    $nama_barang = $_POST['nama_barang'];
    $status = $_POST['status'];
    $lokasi_id = $_POST['lokasi_id'];
    $kategori_id = $_POST['kategori_id'];

    $update = "UPDATE inventaris SET 
        kode_label='$kode_label',
        id_barang='$id_barang',
        nama_barang='$nama_barang',
        status='$status',
        lokasi_id=$lokasi_id,
        kategori_id=$kategori_id
        WHERE id=$id";

    if ($conn->query($update)) {
		echo "<script>alert('Data berhasil diperbarui'); window.location='../data_inventaris.php';</script>";
    } else {
        echo "Gagal update: " . $conn->error;
    }
}
?>
