<?php
include '../includes/db.php';
session_start();

$id = $_GET['id'] ?? null;
if (!$id) {
    die('ID inventaris tidak ditemukan.');
}

// Ambil data inventaris
$sqlInventaris = "SELECT kode_label, id_barang, nama_barang, tanggal_masuk FROM inventaris WHERE id = $id";
$resInventaris = $conn->query($sqlInventaris);
if (!$resInventaris || $resInventaris->num_rows === 0) {
    die("Data inventaris tidak ditemukan.");
}
$inventaris = $resInventaris->fetch_assoc();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $tanggal     = $conn->real_escape_string($_POST['tanggal']);
    $keterangan  = $conn->real_escape_string($_POST['keterangan']);
    $kode_label  = $conn->real_escape_string($inventaris['kode_label']);
    $id_barang   = $conn->real_escape_string($inventaris['id_barang']);
    $nama_barang = $conn->real_escape_string($inventaris['nama_barang']);

    $sqlInsert = "INSERT INTO pemeliharaan (kode_label, id_barang, nama_barang, tanggal, keterangan)
                  VALUES ('$kode_label', '$id_barang', '$nama_barang', '$tanggal', '$keterangan')";

    if (!$conn->query($sqlInsert)) {
        die("Insert error: " . $conn->error);
    }

    $_SESSION['message'] = "Data pemeliharaan berhasil disimpan!";
    header("Location: pemeliharaan.php?id=$id");
    exit();
}

// Ambil riwayat pemeliharaan berdasarkan kode_label
$sqlSelect = "SELECT * FROM pemeliharaan
              WHERE kode_label = '{$inventaris['kode_label']}'
              ORDER BY tanggal DESC";
$result = $conn->query($sqlSelect);
if (!$result) {
    die("Query error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Riwayat Pemeliharaan</title>
</head>
<body>

<?php if (!empty($_SESSION['message'])): ?>
    <p style="color: green;"><?= htmlspecialchars($_SESSION['message']) ?></p>
    <?php unset($_SESSION['message']); ?>
<?php endif; ?>

<h2>Riwayat Pemeliharaan</h2>
<p><strong>Kode Label:</strong> <?= htmlspecialchars($inventaris['kode_label']) ?></p>
<p><strong>ID Barang:</strong> <?= htmlspecialchars($inventaris['id_barang']) ?></p>
<p><strong>Nama Barang:</strong> <?= htmlspecialchars($inventaris['nama_barang']) ?></p>
<p><strong>Tanggal Masuk:</strong> <?= htmlspecialchars($inventaris['tanggal_masuk']) ?></p>

<table border="1" cellpadding="5">
    <tr>
        <th>Tanggal</th>
        <th>Keterangan</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($row['tanggal']) ?></td>
        <td><?= htmlspecialchars($row['keterangan']) ?></td>
    </tr>
    <?php endwhile; ?>
</table>

<h2>Tambah Pemeliharaan</h2>
<form method="POST">
    <label>Tanggal:</label><br>
    <input type="date" name="tanggal" required><br><br>

    <label>Keterangan:</label><br>
    <textarea name="keterangan" rows="4" cols="40" required></textarea><br><br>

    <button type="submit">Simpan</button>
</form>

</body>
</html>
