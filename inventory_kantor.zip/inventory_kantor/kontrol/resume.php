<?php
include '../includes/db.php';
$id = $_GET['id'];
$data = $conn->query("SELECT i.*, l.nama_lokasi, k.nama_kategori 
                      FROM inventaris i 
                      JOIN lokasi l ON i.lokasi_id = l.id 
                      JOIN kategori k ON i.kategori_id = k.id 
                      WHERE i.id = $id")->fetch_assoc();
?>

<h2>Detail Inventaris</h2>
<ul>
    <li>Kode Label: <?= $data['kode_label'] ?></li>
    <li>ID Barang: <?= $data['id_barang'] ?></li>
    <li>Nama Barang: <?= $data['nama_barang'] ?></li>
    <li>Status: <?= $data['status'] ?></li>
    <li>Lokasi: <?= $data['nama_lokasi'] ?></li>
    <li>Kategori: <?= $data['nama_kategori'] ?></li>
    <li>Tanggal Masuk: <?= $data['tanggal_masuk'] ?></li>
</ul>
